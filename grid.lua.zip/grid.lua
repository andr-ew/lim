this.inlets = 1
this.outlets = 1

monome_instance

grid = {
	connect = function ()
		monome instance = Grid:new()

		return monome_instance
	end
}

loadbang = function ()
	init()
end

mute = function (i)
    if monome_instance then
        monome_instance:mute(i)
    end
end

disconnect = function ()
    if monome_instance then
        monome_instance:disconnect()
    end
end

reconnect = function ()
    if monome_instance then
        monome_instance:reconnect()
    end
end

focus = function (i)
    if monome_instance then
        monome_instance:focus(i)
    end
end

grid_input = function (...)
    local grid_inputs = {
        monome = {
            osc = function (n)
                if monome_instance then
                    monome_instance:osc(n)
                end
            end,
            menu = function (n)
                if monome_instance then
                    monome_instance:menu(n)
                end
            end
        }
    }
    
    local n = {}
    for i,v in ipairs(args) do
        if i>2 then
            n[i-2] = v
        end
    end
    
    grid_inputs[args[1]][args[2]](n)
end

input = {}

input_list = function (...)
    local n = {}
    for i,v in ipairs(args) do
        if i>1 then
            n[i-1] = v
        end
    end
    
    input[args[1]](n)
end

output = function (...)
    outlet(0, "out", unpack(args))
end

Monome = {
    event = function () end,
    in_port = 0,
    prefix = "",
    autoconnect = 0,
    connected = 0,
    device = 0,
    index = 1,
    enabled = 1,
    device_size,
    serials = {},
    devices = {},
    ports = {},
    in_port = math.random(1000) + 12288,
    prefix = "/monome",
    autoconnect = 1
}

Monome:new = function (o, f)
    o = o or {}
    setmetatable(o, self)
    self.__index = self

    outlet(0, "monome", 0, "port", self.in_port)
    self.rescan()
    
    if f != nil then f() end
    
    return o
end

Monome:send = function (n)
    if self.enabled then
        outlet(0, "monome", 2, n)
    end
end

Monome:rescan = function ()
    if self.enabled then
        outlet(0, "monome", 1, "/serialosc/list", "localhost", this.in_port)
		outlet(0, "monome", 1, "/serialosc/notify", "localhost", this.in_port)
		outlet(0, "monome", 3, "clear")
		outlet(0, "monome", 3, "append", "none")
		outlet(0, "monome", 3, "textcolor", 1.0, 1.0, 1.0, 0.3)
		
		this.ports = {}
		this.devices = {}
		this.serials = {}
    end
end

Monome:osc = function (n)
    if n[1] == "/serialosc/device" then
        outlet(0, "monome", 3, "append", n[2], n[3])
		self.ports.push(n[4])
		self.devices.push(n[3])
		self.serials.push(n[2])
        
        if self.autoconnect == 1 and self.enabled then
            outlet(0, "monome", 3, 1)
        end
        
        if self.connected and self.enabled then
            local i
            
            for i,v in ipairs(self.serials) do
                if v == self.connected then
                    outlet(0, "monome", 3, i+1)
                end
            end
        end
    elseif n[1] == "/serialosc/remove" or n[1] == "/serialosc/add" then
        if self.enabled then self:rescan() end
    elseif n[1] == "/sys/port" and n[2] != self.in_port then
        outlet(0, "monome", 3, "set", 0)
		outlet(0, "monome", 3, "textcolor", 1.0, 1.0, 1.0, 0.3)
		self.connected = 0
		self.device = 0
    elseif n[1] == "/sys/size" then
        self.device_size = {}
		self.device_size[1] = n[2]
		self.device_size[2] = n[3]
    else
        if self.enabled then self:parse(n)
    end
end

Monome:menu = function (i)
    if self.enabled then
        if i != 0 then
            self.index = i
                
            outlet(0, "monome", 3, "textcolor", 1.0, 1.0, 1.0, 1.0)
			outlet(0, "monome", 2, "port", this.ports[i])
			outlet(0, "monome", 2, "/sys/port", this.in_port)
			outlet(0, "monome", 2, "/sys/prefix", this.prefix)
			outlet(0, "monome", 2, "/sys/info")
			
			outlet(0, "monome", 4, this.serials[i])
			outlet(0, "monome", 5, this.devices[i])
                
            self.connected = self.serials[i];
			self.device = self.devices[i];
			
			self:onreconnect();
        else
            self:ondisconnect()
			
			if self.connected then outlet(0, "monome", 2, "/sys/port", 0)
        end
    end
end
        
Monome:ondisconnect = function () end
        
Monome:onreconnect = function () end
        
Monome:disconnect = function ()
    self:ondisconnect()
    outlet(0, "monome", 3, 0)
end
        
Monome:reconnect = function ()
    outlet(0, "monome", 3, self.index)
    self:onreconnect()
end

Monome:parse = function (n)
    if self.event != nil then
        self:event(n)
    end
end
        
Monome:mute = function (i)
    self.enabled = !i
    
    outlet(0, "monome", 3, "ignoreclick", i)
            
    if i then
        outlet(0, "monome", 3, "textcolor", 1.0, 1.0, 1.0, 0.3)
    else
        outlet(0, "monome", 3, "textcolor", 1.0, 1.0, 1.0, 1.0)
    end
end

Monome:focus = function (i)
    if i then
        self:mute(0)
        self:reconnect()
    else
        self:disconnect()
        self:mute(1)
    end
end

Grid = Monome:new({
                matrix = {},
                quad_off = {{0, 0,}, {8, 0}, {0, 8}, {8, 8}, {16, 0,}, {24, 0}, {16, 8}, {24, 8}},
                quad_count = nil
            }, 
            function () 
                self:all(0) 
            end
        )

Grid:all = function (z)
    for x=0, 15 do
        self.matrix[x] = {}
        
        for y=0, 15 do
            self.matrix[x][y] = z
        end
    end
end
        
Grid:led = function (x, y, z)
    self.matrix[x][y] = z
end
        
        
Grid:refresh = function ()
    if self.device_size != nil then
        
        self.quad_count = self.device_size[0] * self.device_size[1] / 64
                
        for i=1, self.quadcount do
            quad_mess = [self.prefix + "/grid/led/level/map", self.quad_off[i][0], self.quad_off[i][1]]
                    
            for y=1, 8 do
                for x=1, 8 do
                    quad_mess[(y * 8) + x + 3] = self.matrix[x + self.quad_off[i][0]][y + self.quad_off[i][1]]
                end
            end
                    
            self:send(quad_mess)
        end
    else
        --run this function again in 1ms ?
    end
end
        
Grid:parse = function (n)
    if n != nil then
        if n[0] == "/monome/grid/key" then
            self:event(n[1], n[2], n[3])
        end
    else 
        self:refresh()
    end
end
        
Grid:ondisconnect = function () 
    self:send([this.prefix + "/grid/led/level/all", 0])
end
        
Grid:onreconnect = function ()
    self:refresh()
end
        
Grid:mute = function (i)
    if i then
        self:ondisconnect()
        Monome.mute(self, i)
    else
        Monome.mute(self, i)
        self:onreconnect()
    end
end